from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import replicate
import os

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

os.environ["REPLICATE_API_TOKEN"] = os.environ.get("REPLICATE_API_TOKEN", "")

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/swap', methods=['POST'])
def swap():
    try:
        token = os.environ.get("REPLICATE_API_TOKEN")
        if not token:
            return jsonify({"error": "Token do Replicate não configurado"}), 500
        
        if 'selfie' not in request.files or 'target' not in request.files:
            return jsonify({"error": "Envie as duas imagens"}), 400
            
        selfie = request.files['selfie']
        target = request.files['target']
        
        output = replicate.run(
            "codeplugtech/face-swap:9a4298548422074c3f57258c5d544497314ae4112df80d116f0d2109e843d209",
            input={
                "source_image": selfie,
                "target_image": target
            }
        )
        
        result_url = output[0] if isinstance(output, list) else output
        
        if not result_url:
            return jsonify({"error": "Nenhuma imagem gerada"}), 500
            
        return jsonify({"result_url": result_url})
        
    except Exception as e:
        print(f"ERRO: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)